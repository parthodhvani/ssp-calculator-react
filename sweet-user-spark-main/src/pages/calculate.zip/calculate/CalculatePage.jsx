// src/pages/CalculatePage.tsx
import { useEffect, useMemo, useRef, useState } from "react";
import { useCalculatorContent } from "./useCalculatorContent";
import { calculateEntitlement, isLinkedAbsence } from "./entitlement";
import { AcfPageGate } from "../shared/AcfPageGate";

import { HeroSection } from "./components/HeroSection";
import { CalculatorForm } from "./components/CalculatorForm";
import { ResultSummary } from "./components/ResultSummary";
import { HowItWorks } from "./components/HowItWorks";
import { useReport } from "@/context/ReportContext";
import { useRouter } from "@tanstack/react-router";

export function CalculatePage() {
  const { content, isLoading, error, endpoint } = useCalculatorContent();
  const { setReport, clearReport } = useReport();
  const router = useRouter();

  // Effect to scroll to the calculator section when the URL hash is #calculator
  useEffect(() => {
    const hash = window.location.hash;
    if (hash === '#calculator') {
      const element = document.getElementById('calculator');
      if (element) {
        setTimeout(() => {
          element.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      }
    }
  }, [router.state.location.href]);

  useEffect(() => {
    if (import.meta.env.DEV) {
      console.info("[CalculatePage] content source:", {
        endpoint,
        isLoading,
        error,
        heroBadge1: content?.hero?.badge1,
        year1Percent: content?.rules?.year1Percent,
      });
    }
  }, [endpoint, isLoading, error, content?.hero?.badge1, content?.rules?.year1Percent]);

  const calc = content?.calculator;
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [company, setCompany] = useState("");
  const [industry, setIndustry] = useState("");
  const [status, setStatus] = useState("");
  const [linked, setLinked] = useState(false); // UI switch only
  const [linkedFirstDay, setLinkedFirstDay] = useState("");
  const [linkedLastDay, setLinkedLastDay] = useState("");
  const [salary, setSalary] = useState("");
  const [hours, setHours] = useState("");
  const [firstDay, setFirstDay] = useState("");
  const [lastDay, setLastDay] = useState("");

  const prevDefaults = useRef({ salary: "", hours: "", status: "" });

  useEffect(() => {
    if (!calc) return;
    const nextSalary = String(calc.salaryDefault ?? "");
    const nextHours = String(calc.hoursDefault ?? "");
    const nextStatus = calc.statusDefault ?? "";

    setSalary((current) =>
      current === prevDefaults.current.salary ? nextSalary : current,
    );
    setHours((current) =>
      current === prevDefaults.current.hours ? nextHours : current,
    );
    setStatus((current) =>
      current === prevDefaults.current.status ? nextStatus : current,
    );

    prevDefaults.current = {
      salary: nextSalary,
      hours: nextHours,
      status: nextStatus,
    };
  }, [calc?.salaryDefault, calc?.hoursDefault, calc?.statusDefault]);

  // 🔁 Automatic link detection based on the gap between previous last day and new first day
  const linkedAbsenceFlag = useMemo(() => {
    if (!content || !linkedLastDay || !firstDay) return false;
    // Only consider linked if both previous period dates are filled
    if (!linkedFirstDay) return false;
    return isLinkedAbsence(linkedLastDay, firstDay, content.rules);
  }, [content, linkedLastDay, firstDay, linkedFirstDay]);

  // 🧮 Estimate – always uses the auto‑detected linked flag, ignoring the UI switch
  const estimate = useMemo(() => {
    if (!content) return null;
    return calculateEntitlement(
      {
        grossMonthlySalary: Number(salary) || 0,
        contractedHours: Number(hours) || 0,
        firstDay,
        lastDay,
        linked: linkedAbsenceFlag, // automatic detection
        linkedFirstDay: linkedAbsenceFlag ? linkedFirstDay : "",
        linkedLastDay: linkedAbsenceFlag ? linkedLastDay : "",
      },
      content.rules,
    );
  }, [
    content,
    salary,
    hours,
    firstDay,
    lastDay,
    linkedAbsenceFlag,
    linkedFirstDay,
    linkedLastDay,
  ]);

  // Update ReportContext whenever estimate or form fields change
  useEffect(() => {
    if (
      estimate &&
      name.trim() &&
      email.trim() &&
      company.trim() &&
      industry.trim() &&
      status.trim() &&
      Number(salary) > 0 &&
      Number(hours) > 0 &&
      firstDay.trim()
    ) {
      setReport({
        name: name.trim(),
        email: email.trim(),
        company: company.trim(),
        industry: industry.trim(),
        status: status.trim(),
        salary: Number(salary),
        hours: Number(hours),
        firstDay: firstDay.trim(),
        lastDay: lastDay.trim(),
        linked: linkedAbsenceFlag,
        linkedFirstDay: linkedAbsenceFlag ? linkedFirstDay.trim() : "",
        linkedLastDay: linkedAbsenceFlag ? linkedLastDay.trim() : "",
        estimate,
        generatedDate: new Date().toISOString(),
      });
    } else {
      clearReport();
    }
  }, [
    estimate,
    name,
    email,
    company,
    industry,
    status,
    salary,
    hours,
    firstDay,
    lastDay,
    linkedAbsenceFlag,
    linkedFirstDay,
    linkedLastDay,
    setReport,
    clearReport,
  ]);

  const form = {
    name,
    setName,
    email,
    setEmail,
    company,
    setCompany,
    industry,
    setIndustry,
    status,
    setStatus,
    linked,
    setLinked,
    linkedFirstDay,
    setLinkedFirstDay,
    linkedLastDay,
    setLinkedLastDay,
    salary,
    setSalary,
    hours,
    setHours,
    firstDay,
    setFirstDay,
    lastDay,
    setLastDay,
    linkedAbsenceFlag,
  };

  return (
    <AcfPageGate isLoading={isLoading} error={error} label="calculator">
      {content ? (
        <main className="flex-1">
          <HeroSection content={content} />

          <section id="calculator" className="mx-auto max-w-6xl px-6 py-16">
            <div className="mb-10">
              <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-accent">
                {content.section.kicker}
              </p>
              <h2 className="mt-2 font-serif text-3xl tracking-tight text-foreground sm:text-4xl">
                {content.section.title}
              </h2>
              <p className="mt-2 max-w-xl text-sm text-muted-foreground">
                {content.section.description}
              </p>
            </div>

            <div
              className="grid gap-8 rounded-2xl border border-border bg-card p-5 sm:p-8 lg:grid-cols-[1.35fr_1fr] lg:gap-10"
              style={{ boxShadow: "var(--shadow-card)" }}
            >
              <CalculatorForm content={content} form={form} estimate={estimate} />
              <ResultSummary content={content} estimate={estimate} />
            </div>
          </section>

          <HowItWorks content={content} />
        </main>
      ) : null}
    </AcfPageGate>
  );
}

export default CalculatePage;